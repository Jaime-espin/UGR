#ifndef DESCIFRA_H
#define DESCIFRA_H

#include <string>
using namespace std;

unsigned int longitudCad(char cs[]);
bool comienzaPalabra(char cs[], int );
bool terminaPalabra(char cs[], int );
void descifra(char cs[], char rta[]);


#endif
